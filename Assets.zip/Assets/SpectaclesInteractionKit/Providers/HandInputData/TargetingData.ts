export type TargetingData = {
  targetingDirectionInWorld: vec3
  targetingLocusInWorld: vec3
}
