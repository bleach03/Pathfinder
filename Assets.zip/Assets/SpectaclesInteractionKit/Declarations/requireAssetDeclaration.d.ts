declare function requireAsset(path: string): Asset
