/**
 * Axis-Aligned Bounding-Box representation
 */
export type aabb = {
  min: vec3
  max: vec3
}
