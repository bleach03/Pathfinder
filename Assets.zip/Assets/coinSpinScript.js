// @input SceneObject coin

var rotationSpeed = 90;

function onUpdate(eventData) {
    var currentRotation = script.coin.getTransform().getLocalRotation();
    var newRotation = quat.fromEulerAngles(0, rotationSpeed*getDeltaTime(), 0);
    script.coin.getTransform().setLocalRotation(currentRotation.multiply(newRotation));
    
}

script.createEvent("UpdateEvent").bind(onUpdate);